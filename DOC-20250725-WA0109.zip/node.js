// Add event listener to the button
document.querySelector('button').addEventListener('click', () => {
    // Add animation to the button
    document.querySelector('button').classList.add('animate');
    // Redirect to a new page or perform an action
    // window.location.href = 'new-page.html';
});